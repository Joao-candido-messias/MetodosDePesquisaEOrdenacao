package pesquisa;

public class Pesquisa {

    public static int digital(java.awt.event.KeyEvent evt, String pesquisa, String texto) {

        char c = evt.getKeyChar();
        StringBuffer palavraDigitada;

        if (!Character.isISOControl(c)) {
            palavraDigitada = new StringBuffer(pesquisa + c);
        } else {
            palavraDigitada = new StringBuffer(pesquisa);
        }

        int ocorrencias = 0;
        String textoArea = texto;
        int tamPalavra = palavraDigitada.length();

        if (tamPalavra > 0) {
            for (int i = 0; i <= textoArea.length() - tamPalavra; i++) {
                if (textoArea.substring(i, i + tamPalavra)
                        .equalsIgnoreCase(palavraDigitada.toString())) {
                    ocorrencias++;
                }
            }
        }

        return ocorrencias;
    }
}